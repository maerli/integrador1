#include<stdio.h>
#include<stdlib.h>

int main(){
	cout << "maerli" << endl;
	return 0;
}