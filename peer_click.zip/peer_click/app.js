﻿var express = require('express');
var shell = require('shelljs');
var fs = require('fs');
var ip = require('./ip');
var socket = require('socket.io');
var all_itens = Object.keys(require('./public/itens').itens);

//shell.exec('shell.bat');

// criando uma lista de dados em public
//variaveis de configuração
let port = 3000;

//getIP é uma função para mostrar o endereço de IP
//do computador
console.log(`
	Abra seu navegador e digite:
	${ip.getIP()}:${port}
		ou
	${ip.getIP()}:${port}/show

	`);



var item = 0; // item que está sendo votado



//por padrão a contagm começa a partir do item 1
var user = 1;//

/*
	Ao conectar-se ao servidor o aluno é identificado com um número
	que por padrão se inicia no 1.
	user = 1,
	a medida que outros alunos se conectam a variavel user é incrementada
*/

var users = [];
//guardar quais usuarios respoderam ao item corrente

function save(){
	//salva em 'dados.txt' no formato JSON, para futuras analises dos dados
	fs.writeFile('dados.txt',JSON.stringify(itens),'utf8',function(data){
		console.log('dados gravados com sucesso');
	});
}

var itens = [{'item':all_itens[item]}];

var app = express();

app.get('/aluno',function(req,res){
	res.send( "show.html" );
});

app.use(express.static(__dirname + '/public'));

var server = app.listen(port, function () {
  console.log('Example app listening on port 3000!');
  console.log(`Abrindo navegador chrome em segundos...
  Caso não inicie automatimente, faça o processo manualmente.`);

  shell.exec('start chrome http://' + ip.getIP() + ':3000/show.html');
});

var io = socket(server);

io.sockets.on('connection',function(sockets){
	//console.log('nova conexao' + sockets.id);

	sockets.emit('change',itens[itens.length - 1]);

	sockets.on('answer',function(data){
		if(users.indexOf(parseInt(data.user)) == -1){
			users.push(parseInt(data.user));		
			if(data.text != undefined){
				if(itens[item]['respond'] == undefined){
					itens[item]['respond'] = [data.text];
				}else{
					itens[item]['respond'].push(data.text);
				}
			}else{
				if(itens[item][data.vowel] == undefined){
					itens[item][data.vowel] = 1;
				}else{
					itens[item][data.vowel] += 1;
				}
			}
			sockets.broadcast.emit('change',itens[itens.length-1]);
		}

		console.log(data);

	});

	sockets.on('init',function(data){
		if(data == null){
			sockets.emit('user',user);
			user += 1;
		}else{
			sockets.emit('user',data);
		}
	});

	sockets.on('same',function(data){
		users = [];
		itens.push({'item':all_itens[item]});
		reload(io.sockets);
		save();
		io.sockets.emit('change',itens[itens.length -1]);
	});
	sockets.on('clear',function(){
		users = [];
		item = 0;
		itens = [{'item':all_itens[item]}];
		reload(io.sockets,true);

	});
	sockets.on('check',function(data){
		sockets.emit('check',{'isclicked':users.indexOf(parseInt(data)) == -1,'item':all_itens[item]});
		console.log(users);
	});

	sockets.on('change',function(data){
		item += 1;
		users = [];
		itens.push({'item':all_itens[item]});
		reload(io.sockets);
		save();
		io.sockets.emit('change',itens[itens.length - 1]);
	});

	sockets.on('disconnect',function(data){
		//console.log(sockets.id + ' foi disconecatado!');
	});
});


var material_de_aula;
try{
	material_de_aula = fs.readFileSync('material.out','utf-8');
	array_material = material_de_aula.split('\n');
}catch(err){
	array_material = [];
	console.log('crie pasta material');
}
array_material = array_material.map(function(element){
	var allNames = element.split('\\peerclick\\');
	var firstPartName = allNames[0];
	var secondPartName = allNames[1];

	if(firstPartName == undefined || secondPartName== undefined){
		return "";
	}else{
		secondPartName = secondPartName.replace(/\r/g,'');
		app.get('/'+encodeURI(secondPartName),function(req, res){
			res.download((firstPartName + '\\peerclick\\' + secondPartName).replace(/\\/g,'/'));
		});
		return secondPartName;
	}
});

app.get('/material_de_aula',function(req, res){

	var html = `
	<!doctype html>
	<html>
	<head>
	<meta name="viewport" content="width=device-width, user-scalable=no">
	<title>Material de aula</title>
	</head>
	</body>

	${array_material.map(function(a){
		return '<a href=\''+ encodeURI(a) 
		+'\'>' + a + '</a>';
	}).join('<br>')}
	</html>
	`;
	res.send(html);
});

app.get('/show',function(req,res){
	res.send("show.html" );
});

app.get('/change',function(req,res){
	res.send('ok');
});

function reload(b,c){
	b.emit('reload',c!=undefined?c:itens.length);
}