/* ITEM : ["descrição do item",
        "opção A",
         "opção B",
         "opção C",
         "opção D",
         "opção E"
]
*/
itens = {
  "1":[
    "*",
    "Digite seu nome:",
    "<input class='valor' type='text'>"
  ],
  "2":[
    "Quais as suas maiores dificuldades em física?",
    "A matemática envolvida",
    "Análise de gráficos",
    "Relacionar teoria e prática",
    "A falta de métodos de ensino atrativos",
    "Não tenho dificuldades",

  ],
  "3":[
    "O que você mais gosta na disciplina de física?",
    "A matemática envolvida",
    "As aplicações experimentais",
    "O conceito, sem a matemática",
    "Tudo",
    "Nada"
  ],
  "4":[
    "Pra você, o uso de figuras, animações e similares ajuda na compreensão dos problemas discutidos na disciplina de física?",
    "Sempre",
    "Muitas vezes",
    "Às vezes",
    "Raramente",
    "Nunca"
  ],
  "5":[
    "Você já teve alguma outra experiência com o Modellus ou um Software similar?",
    "Sim, O Modellus",
    "Sim, outro Software",
    "Não",
    "Não lembro",
  ],
  "6":[
    "Qual sua opinião a respeito da ferramenta de aprendizagem?",
    "Interessante, poderia ser usado com mais frequência",
    "Interessante, mas prefiro a aula tradicional",
    "Interessante, mas não me interesso por física",
    "Pouco atrativo, pois não consegui entender",
    "Pouco atrativo, mas entendi tudo"
  ],
  "7":[
    "A ferramenta apresentada ajudou de alguma forma no seu aprendizado?",
    "Não, de forma nenhuma",
    "Muito pouco",
    "Razoavelmente",
    "Sim, bastante"
    ],
  "8":[
    "*",
    "Você tem alguma sugestão para tornar as aulas de física mais atrativas?",
    "<textarea class='valor' placeholder='Descreva...'></textarea>"
  ]
}

module.exports = {
  "itens":itens
}
