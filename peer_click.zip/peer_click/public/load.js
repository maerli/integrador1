//a variavel item esta no script itens.js
var item_type;
let MSG = {
	item:{
		'paraResponder':'Item ainda não respondido',
		'jaRespondido':'Este item já foi Respondido, espere o próximo item...',
		'responderNovamente':'Responder este item novamente'
		}
}


function $(id){
	return document.querySelector(id);
}

function solve(text){
	$('.solve').innerHTML = MSG.item[text];
}


function setUser(item){
	var store = sessionStorage.setItem('answer',item);
}
function getUser(str){
	return sessionStorage.getItem('answer');
}

addEventListener('load',function(){
	var vowel = '';

	function send(vowel){
		var options = {'user':getUser(),'vowel':vowel};
		if(itens[item_type][0] == '*'){
			options.text = $('.valor').value;

		}
		console.log(options);
		socket.emit('answer',options);
		it = true;
		button.disabled = true;
	}
	var clicked;
	it = true;
	
	function insertClickOption(){
		var spans = document.querySelectorAll('.box');
		for(var i = 0;i < spans.length;i++){
			spans[i].addEventListener('click',function(){
				button.disabled = it;
				vowel = this.id;
				if(clicked){
					clicked.style.backgroundColor = 'rgba(255,250,20,0.5)';
					clicked.style.color = 'black';
				}
				this.style.backgroundColor = 'blue';
				this.style.color = 'white';
				clicked = this;
			});
		}
	}

	var button = document.querySelector('button');
	button.addEventListener('click',function(){
		send(vowel,item_type);
		solve('jaRespondido');
	});

	socket = io.connect(location.host);
	socket.emit('init',getUser());
	socket.on('reload',function(item){
		reload(clicked,item);
		it = false;
	});
	socket.on('clear',function(){
		sessionStorage.clear();
	});
	socket.on('user',function(user){
		if(getUser() == null){
			setUser(user);
		}
	socket.emit('check',getUser());
	});
	
	/*socket.on('change_number',function(data){
		var spn = document.querySelectorAll('.box');
		for(let i = 0;i<5;i++){
			if(data > i){
				spn[i].style.display = 'inline-block';
			}else{
				spn[i].style.display = 'none';
			}
		}
	});
	*/

	socket.on('check',function(data){
		if(data.isclicked){
			reload(clicked,data.item);
		}else{
			solve('jaRespondido');
		}
		it = !data.isclicked;
	});

function ponte(data){
	let letters = ['a','b','c','d','e',"f","g","h","i"];
	return data.map(function(x,y){
		if(y == 0){
			if(x == '*'){
				return '';
			}else{
				return '<span class=\'real-item\'>'+ x +'</span>';
			}
		}else{
			if(data[0] == '*'){
				return x;
			}else{
				return '<span class=\'box\' id=\''+letters[y - 1]+'\' > ' + letters[y - 1] + ')\t ' + x + '</span>';
			}
	}}).join('<br>');

}

function reload(clicked,item){
	item_type = item;
	if(itens[item_type] == undefined){
		var audio = document.createElement('video');
		audio.src= 'urna.mp3';
   		audio.play();


		$('#item').innerHTML = 'Fim questionário!';

	}else{
		if(clicked){
			clicked.style.backgroundColor = 'blue';
			clicked.style.color = 'white';
		}
		if(itens[item]){
			$('#item').innerHTML = ponte(itens[item]);
			try{
				$('.valor').addEventListener('keyup',function(event){
					if(this.value != ''){
						button.disabled = false;
					}
				});
			}catch(err){
				//console.log('erro!');
			}
		}
		insertClickOption();
		button.disabled = true;
		solve('paraResponder');
	}
}
});


