function exec(shell){
 	
}
module.exports = {
 				"exec":exec
 				}