# peerclick
Para executar esta aplicação você deve instalar os seguintes pacotes.

* *express* 
* *socket.io*

# Instalando os pacotes

Respectivamente:

`npm install express --save` 

`npm install socket.io --save`